import React from 'react'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import './index.css'

export default function App(){
  return (
    <div className="min-h-screen flex flex-col bg-srblack text-srwhite">
      <Header />
      <main className="flex-1">
        <Home />
      </main>
      <Footer />
    </div>
  )
}

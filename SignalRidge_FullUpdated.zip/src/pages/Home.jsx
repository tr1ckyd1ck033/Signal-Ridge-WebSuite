import React from 'react'
import DownloadCard from '../components/DownloadCard'

export default function Home(){
  return (
    <div id="home" className="relative">
      <div className="watermark"></div>

      {/* HERO */}
      <section id="hero" className="min-h-[60vh] flex items-center">
        <div className="max-w-6xl mx-auto px-6 md:px-12 py-20">
          <h1 className="text-5xl md:text-6xl font-display mb-3">Signal Ridge</h1>
          <div className="w-28 h-1 bg-gradient-to-r from-transparent via-sryellow to-transparent rounded mb-6"></div>
          <p className="text-lg md:text-xl max-w-3xl text-gray-300 mb-8">
            We find what others can’t. Signal Ridge combines OSINT, discreet investigations, and field operations to deliver verifiable answers — quietly, lawfully, and with absolute clarity.
          </p>
          <div className="flex gap-4">
            <a href="#contact" className="inline-block px-6 py-3 bg-sryellow text-black font-semibold rounded">Get Verified</a>
            <a href="/docs/intake-form.pdf" className="inline-block px-6 py-3 border border-white rounded">Download Intake</a>
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="py-20 border-t border-srgray">
        <div className="max-w-6xl mx-auto px-6 md:px-12">
          <h2 className="text-3xl font-semibold mb-3 section-title">Who we are</h2>
          <div className="gold-divider mb-6"></div>
          <p className="text-lg text-gray-300 leading-relaxed max-w-3xl">
            Signal Ridge is a compact team of investigators, analysts, and field operatives delivering answers for clients across Idaho and beyond. We combine old-school legwork with modern OSINT to find the truth, verify it, and present it in a way that matters.
          </p>

          <div className="mt-8 grid md:grid-cols-2 gap-6">
            <div className="p-6 border border-srgray rounded">
              <h4 className="font-semibold">R. M. Thomas Livingston — Founder</h4>
              <p className="mt-2 text-gray-300">A finder by trade and a problem solver by habit. I started Signal Ridge to deliver clear, actionable intelligence without drama.</p>
            </div>

            <div className="p-6 border border-srgray rounded">
              <h4 className="font-semibold">Core values</h4>
              <ul className="list-disc ml-6 text-gray-300 mt-2">
                <li>Precision</li>
                <li>Discretion</li>
                <li>Integrity</li>
                <li>Execution</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section id="services" className="py-20 border-t border-srgray">
        <div className="max-w-6xl mx-auto px-6 md:px-12">
          <h2 className="text-3xl font-semibold mb-6 section-title">Services</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-6 border border-srgray rounded">
              <h3 className="font-semibold">OSINT</h3>
              <p className="text-gray-300 mt-2">Digital investigation & pattern mapping. We turn open sources into answers.</p>
            </div>
            <div className="p-6 border border-srgray rounded">
              <h3 className="font-semibold">Sentinel</h3>
              <p className="text-gray-300 mt-2">Skip tracing, asset location, and verification.</p>
            </div>
            <div className="p-6 border border-srgray rounded">
              <h3 className="font-semibold">Field Ops</h3>
              <p className="text-gray-300 mt-2">On-site verification & logistics. Discreet, documented, lawful.</p>
            </div>
          </div>
        </div>
      </section>

      {/* DOCS */}
      <section id="docs" className="py-20 border-t border-srgray">
        <div className="max-w-6xl mx-auto px-6 md:px-12">
          <h2 className="text-3xl font-semibold mb-6 section-title">Documentation</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <DownloadCard title="Intake Form" file="intake-form.pdf" desc="Fillable client intake form."/>
            <DownloadCard title="Confidential Agreement (NDA)" file="nda.pdf" desc="Confidential Engagement Agreement."/>
            <DownloadCard title="Intel Report Template" file="intel-report-template.pdf" desc="Report template for deliverables."/>
            <DownloadCard title="Master Operations" file="master-operations.pdf" desc="Full operations architecture."/>
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="py-20 border-t border-srgray">
        <div className="max-w-6xl mx-auto px-6 md:px-12 grid md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-3xl mb-4">Contact & Intake</h2>
            <p className="text-gray-300 mb-6">For urgent matters call <strong>(add phone)</strong>. Otherwise use the intake form or the contact form.</p>
            <a href="/docs/intake-form.pdf" className="inline-block px-5 py-3 border border-white rounded">Download Fillable Form</a>
          </div>

          <aside>
            <h3 className="mb-3">Security note</h3>
            <p className="text-gray-300">For sensitive files use ProtonDrive or Tresorit. Avoid sending attachments over unencrypted email.</p>
          </aside>
        </div>
      </section>
    </div>
  )
}

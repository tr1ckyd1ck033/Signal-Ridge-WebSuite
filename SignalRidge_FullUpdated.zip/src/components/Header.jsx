import React from 'react'

export default function Header(){
  return (
    <header className="py-6 border-b border-srgray bg-transparent sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-6 md:px-12 flex items-center justify-between">
        <a href="#home" className="flex items-center gap-4">
          <img src="/assets/logo-white.png" alt="Signal Ridge" className="h-12 md:h-16 object-contain"/>
        </a>

        <nav className="hidden md:flex gap-6 items-center text-sm">
          <a href="#about" className="hover:text-sryellow transition-colors">About</a>
          <a href="#services" className="hover:text-sryellow transition-colors">Services</a>
          <a href="#docs" className="hover:text-sryellow transition-colors">Docs</a>
          <a href="#contact" className="hover:text-sryellow transition-colors">Contact</a>
          <a href="/portal" className="ml-4 px-3 py-1 rounded border border-white text-sm hover:bg-sryellow hover:text-black transition-colors">Client Portal</a>
        </nav>

        <div className="md:hidden">
          <a href="#contact" className="px-3 py-1 rounded border border-white text-sm hover:bg-sryellow hover:text-black transition-colors">Contact</a>
        </div>
      </div>
    </header>
  )
}
